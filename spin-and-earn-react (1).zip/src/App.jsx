import React, { useState, useEffect } from "react";
import { motion } from "framer-motion";
import confetti from "canvas-confetti";

export default function App() {
  const [balance, setBalance] = useState(0);
  const [spinsLeft, setSpinsLeft] = useState(3);
  const [referrals, setReferrals] = useState(0);
  const [spinResult, setSpinResult] = useState(null);
  const [page, setPage] = useState("home");
  const [admin, setAdmin] = useState(false);
  const [adminLogin, setAdminLogin] = useState({ email: "", password: "" });
  const [paymentLink, setPaymentLink] = useState("");

  const prizes = ["₹10", "₹20", "₹50", "₹100", "₹200", "₹500", "₹1000", "Jackpot"];

  // Load saved state from localStorage
  useEffect(() => {
    const saved = JSON.parse(localStorage.getItem("spinapp_state") || "{}");
    if (saved.balance) setBalance(saved.balance);
    if (saved.spinsLeft !== undefined) setSpinsLeft(saved.spinsLeft);
    if (saved.referrals) setReferrals(saved.referrals);
    if (saved.paymentLink) setPaymentLink(saved.paymentLink);
    const lastReset = localStorage.getItem("lastReset");
    const now = new Date().getDate();
    if (parseInt(lastReset) !== now) {
      setSpinsLeft(3);
      localStorage.setItem("lastReset", now);
    }
  }, []);

  useEffect(() => {
    const state = { balance, spinsLeft, referrals, paymentLink };
    localStorage.setItem("spinapp_state", JSON.stringify(state));
  }, [balance, spinsLeft, referrals, paymentLink]);

  const handleSpin = () => {
    if (spinsLeft <= 0) {
      alert("You’ve reached your daily 3-spin limit. Come back tomorrow!");
      return;
    }
    const randomPrize = prizes[Math.floor(Math.random() * prizes.length)];
    setSpinResult(randomPrize);
    setSpinsLeft((prev) => prev - 1);

    if (randomPrize !== "Jackpot") {
      const amount = parseInt(randomPrize.replace("₹", ""));
      setBalance((prev) => prev + amount);
    } else {
      setBalance((prev) => prev + 1000);
    }

    // confetti animation
    confetti();
  };

  const handleRedeem = () => {
    if (referrals < 10) {
      alert("Share the app with 10 friends to unlock redeem option!");
    } else {
      if (!paymentLink) {
        alert("Admin has not set a payment link yet. Please try later.");
        return;
      }
      window.open(paymentLink, "_blank");
    }
  };

  const handleAdminLogin = () => {
    // Admin credentials provided by owner
    if (adminLogin.email === "samim731948@gmail.com" && adminLogin.password === "Samim123") {
      setAdmin(true);
      setPage("admin");
    } else {
      alert("Invalid credentials!");
    }
  };

  const Home = () => (
    <div className="min-h-screen flex flex-col items-center p-6 text-white">
      <h1 className="text-3xl font-bold text-yellow-400 mb-4">🎯 Spin and Earn</h1>
      <div className="bg-gray-800 text-center w-full max-w-md p-6 rounded-xl shadow-lg">
        <p className="text-green-400 text-lg font-semibold">Wallet Balance: ₹{balance}</p>
        <p className="text-orange-400">Spins left today: {spinsLeft} / 3</p>
        <motion.div
          whileTap={{ rotate: 360 }}
          transition={{ duration: 1 }}
          className="mt-6 bg-gradient-to-r from-yellow-500 to-orange-500 text-black rounded-full px-8 py-3 font-bold cursor-pointer inline-block"
          onClick={handleSpin}
        >
          🎡 SPIN NOW
        </motion.div>
        {spinResult && (
          <p className="mt-4 text-lg">
            🎉 You won <span className="text-yellow-400 font-bold">{spinResult}</span>!
          </p>
        )}
        <div className="mt-6 flex flex-col gap-3">
          <button onClick={() => setPage("redeem")} className="bg-green-600 hover:bg-green-700 rounded px-4 py-2">
            💸 Redeem
          </button>
          <button onClick={() => setPage("referral")} className="bg-red-600 hover:bg-red-700 rounded px-4 py-2">
            👥 Refer & Earn
          </button>
          <button onClick={() => setPage("adminLogin")} className="bg-gray-700 hover:bg-gray-600 rounded px-4 py-2">
            ⚙️ Admin Login
          </button>
        </div>
      </div>
    </div>
  );

  const Referral = () => (
    <div className="min-h-screen flex flex-col items-center p-6 text-white">
      <h2 className="text-2xl text-yellow-400 font-bold mb-2">👥 Refer & Earn</h2>
      <p>Invite 10 friends to unlock Redeem!</p>
      <p className="mt-2">Referrals completed: {referrals} / 10</p>
      <button
        onClick={() => {
          setReferrals((r) => (r < 10 ? r + 1 : r));
          if (navigator.share) {
            navigator.share({
              title: "Spin and Earn",
              text: "I earned ₹900 in one day from this Spin and Earn app! Try it now!",
              url: window.location.href,
            }).catch(()=>{});
          } else {
            // fallback: copy link
            navigator.clipboard && navigator.clipboard.writeText(window.location.href);
            alert("Share link copied to clipboard!");
          }
        }}
        className="bg-yellow-500 hover:bg-yellow-600 rounded px-4 py-2 mt-4"
      >
        📤 Share Now
      </button>
      <button onClick={() => setPage("home")} className="bg-gray-700 hover:bg-gray-600 rounded px-4 py-2 mt-6">
        ⬅️ Back
      </button>
    </div>
  );

  const Redeem = () => (
    <div className="min-h-screen flex flex-col items-center p-6 text-white">
      <h2 className="text-2xl text-yellow-400 font-bold mb-2">💸 Redeem</h2>
      {referrals < 10 ? (
        <p>Share with 10 friends to unlock redeem option.</p>
      ) : (
        <button onClick={handleRedeem} className="bg-green-600 hover:bg-green-700 rounded px-4 py-2 mt-4">
          Redeem Now
        </button>
      )}
      <button onClick={() => setPage("home")} className="bg-gray-700 hover:bg-gray-600 rounded px-4 py-2 mt-6">
        ⬅️ Back
      </button>
    </div>
  );

  const AdminLogin = () => (
    <div className="min-h-screen flex flex-col items-center justify-center p-6 text-white">
      <h2 className="text-2xl font-bold text-yellow-400 mb-4">🔐 Admin Login</h2>
      <input
        type="email"
        placeholder="Email"
        className="mb-2 p-2 rounded bg-gray-800 text-white w-full max-w-md"
        onChange={(e) => setAdminLogin({ ...adminLogin, email: e.target.value })}
      />
      <input
        type="password"
        placeholder="Password"
        className="mb-2 p-2 rounded bg-gray-800 text-white w-full max-w-md"
        onChange={(e) => setAdminLogin({ ...adminLogin, password: e.target.value })}
      />
      <button onClick={handleAdminLogin} className="bg-green-600 hover:bg-green-700 rounded px-4 py-2 mt-2">
        Login
      </button>
      <button onClick={() => setPage("home")} className="bg-gray-700 hover:bg-gray-600 rounded px-4 py-2 mt-4">
        ⬅️ Back
      </button>
    </div>
  );

  const AdminPanel = () => (
    <div className="min-h-screen flex flex-col items-center p-6 text-white">
      <h2 className="text-2xl text-yellow-400 font-bold mb-4">📊 Admin Dashboard</h2>
      <input
        value={paymentLink}
        onChange={(e) => setPaymentLink(e.target.value)}
        placeholder="Payment Link (set your Razorpay / Cashfree / UPI gateway link)"
        className="p-2 bg-gray-800 text-white rounded w-full max-w-md"
      />
      <button onClick={() => { localStorage.setItem('spinapp_state', JSON.stringify({ balance, spinsLeft, referrals, paymentLink })); alert('Payment link saved to local storage!'); }} className="bg-green-600 hover:bg-green-700 rounded px-4 py-2 mt-3">
        Save
      </button>
      <button onClick={() => { setAdmin(false); setPage('home'); }} className="bg-gray-700 hover:bg-gray-600 rounded px-4 py-2 mt-6">
        🔓 Logout
      </button>
    </div>
  );

  return (
    <>
      {page === "home" && <Home />}
      {page === "referral" && <Referral />}
      {page === "redeem" && <Redeem />}
      {page === "adminLogin" && <AdminLogin />}
      {page === "admin" && admin && <AdminPanel />}
    </>
  );
}
