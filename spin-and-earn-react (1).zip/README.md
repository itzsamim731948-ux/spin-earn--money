# Spin and Earn - React (Vite + Tailwind)

**Project name:** Spin and Earn

## What’s inside
- React + Vite starter
- Tailwind CSS
- Framer Motion for small animations
- canvas-confetti for confetti on win
- LocalStorage-based state (balance, referrals, payment link)
- Admin login (email: samim731948@gmail.com, password: Samim123)

## How to run locally
1. Install dependencies:
   ```
   npm install
   ```
2. Start dev server:
   ```
   npm run dev
   ```
3. Build for production:
   ```
   npm run build
   ```

## Deploy
- Deploy on Vercel / Netlify / Render by pointing to this repo or uploading the folder.

**Important:** This project uses LocalStorage for demo purposes. For production use:
- Add a proper backend (database + authentication).
- Use a secure payment gateway integration (Razorpay / Cashfree / Paytm).
- Do not store admin credentials in frontend code.
